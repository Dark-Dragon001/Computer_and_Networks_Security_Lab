Computer and Networks security Lab.

The script I have built is based on ping command, which takes two pingable ip addresses and pings them. Each ping operation sends 10 packets and than stops.
The ping result is saved to the same dirctory as "log.txt" and "log2.txt". In addition, these two log files are printed on the terminal using the "cat" command.
Finally, at the end of the script excution the location of the files are shown as well.

The commands that are used in this script are such as: " echo, ping, cat, readlink, read".





										Muhammad Rafi Khudaydar
										150709051
