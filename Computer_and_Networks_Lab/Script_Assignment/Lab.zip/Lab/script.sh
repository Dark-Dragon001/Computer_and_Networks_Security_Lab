#!/bin/sh

echo "You can ping two Ip addresses"
echo "Type your first Ip address:";	read Ip_address 
echo "Type your second Ip address:";	read Ip_address2 

echo "Pinging your first Ip address... $Ip_address \n"
ping -c 10 $Ip_address > log.txt 
cat log.txt 
echo "\n"

echo "Pinging your second Ip address... $Ip_address2 \n"
ping -c 10 $Ip_address > log2.txt 
cat log2.txt

echo "\n The Information above was intialised by CAT command. \n"
echo "The log file is created in this directory: "
readlink -f log.txt
readlink -f log2.txt

echo "\n \n Computer and Network Security Lab. Thank you for your time."
echo " Lab Assistan Selahittin hoca."
